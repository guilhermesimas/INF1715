T2 Compiladores - Guilherme Simas 1311812

COMO UTILIZAR:
Em um ambiente Linux, assegure-se que o "environment" se encontre no diretorio onde se encontra o arquivo Makefile.
Em seguida, execute "make". Isso ira gerar o programa out. Rode o programa dando como entrada o arquivo de input.
